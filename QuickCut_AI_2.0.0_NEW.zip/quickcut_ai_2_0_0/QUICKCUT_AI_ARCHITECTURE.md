# QuickCut AI 2.0.0 architecture

Flutter -> FastAPI -> Auth/Projects -> Upload Service -> Media Analysis -> AI Planner -> Job Queue -> FFmpeg Renderer -> Preview/Final.

Production adapters: S3/R2/GCS object storage, signed URLs, PostgreSQL, Redis/Celery, CDN, GPU workers, Google/Apple OAuth and push notifications.
