# QuickCut AI backend

1. Install FFmpeg.
2. `python -m venv .venv && source .venv/bin/activate`
3. `pip install -r requirements.txt`
4. `cp .env.example .env` and set `OPENAI_API_KEY`.
5. `uvicorn app.main:app --reload --port 8000`

The OpenAI key stays server-side. Without it, the app clearly uses DEMO/FALLBACK planning rather than pretending the fallback is AI.
