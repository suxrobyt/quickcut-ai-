from pydantic_settings import BaseSettings, SettingsConfigDict
from pathlib import Path
class Settings(BaseSettings):
    app_name:str="QuickCut AI"
    env:str="development"
    secret_key:str="change-this-in-production"
    database_url:str="sqlite:///./quickcut.db"
    storage_dir:str="./storage"
    public_base_url:str="http://localhost:8000"
    openai_api_key:str=""
    openai_model:str="gpt-5.6-luna"
    max_upload_mb:int=2048
    chunk_size_mb:int=8
    model_config=SettingsConfigDict(env_file=".env", extra="ignore")
settings=Settings()
Path(settings.storage_dir).mkdir(parents=True,exist_ok=True)
