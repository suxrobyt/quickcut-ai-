from pydantic import BaseModel,Field
from typing import Literal
class RegisterIn(BaseModel): email:str; password:str=Field(min_length=6)
class LoginIn(RegisterIn): pass
class ProjectIn(BaseModel):
    name:str="Untitled Project"; instruction:str=""; style:str="AUTO"; aspect_ratio:str="9:16"; duration:str="AUTO"
class ProjectOut(BaseModel):
    id:str; name:str; instruction:str; style:str; aspect_ratio:str; duration:str; status:str; timeline:dict; preview_url:str|None=None; final_url:str|None=None
    class Config: from_attributes=True
class EditRequest(BaseModel): instruction:str; regenerate:bool=False
class RenderRequest(BaseModel): quality:Literal["720p","1080p","4k"]="1080p"
