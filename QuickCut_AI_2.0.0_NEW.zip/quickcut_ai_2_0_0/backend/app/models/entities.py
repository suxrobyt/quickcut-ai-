import uuid
from datetime import datetime,timezone
from sqlalchemy import String,Text,DateTime,ForeignKey,Float,Integer,JSON
from sqlalchemy.orm import Mapped,mapped_column,relationship
from ..db import Base

def uid(): return str(uuid.uuid4())
class User(Base):
    __tablename__="users"
    id:Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    email:Mapped[str]=mapped_column(String(255),unique=True,index=True)
    password_hash:Mapped[str]=mapped_column(String(255))
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
class Project(Base):
    __tablename__="projects"
    id:Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id:Mapped[str]=mapped_column(ForeignKey("users.id"),index=True)
    name:Mapped[str]=mapped_column(String(200),default="Untitled Project")
    instruction:Mapped[str]=mapped_column(Text,default="")
    style:Mapped[str]=mapped_column(String(40),default="AUTO")
    aspect_ratio:Mapped[str]=mapped_column(String(10),default="9:16")
    duration:Mapped[str]=mapped_column(String(10),default="AUTO")
    status:Mapped[str]=mapped_column(String(40),default="DRAFT")
    timeline:Mapped[dict]=mapped_column(JSON,default=dict)
    preview_path:Mapped[str|None]=mapped_column(String(500),nullable=True)
    final_path:Mapped[str|None]=mapped_column(String(500),nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc),onupdate=lambda:datetime.now(timezone.utc))
    media=relationship("Media",back_populates="project",cascade="all, delete-orphan")
class Media(Base):
    __tablename__="media"
    id:Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    project_id:Mapped[str]=mapped_column(ForeignKey("projects.id"),index=True)
    kind:Mapped[str]=mapped_column(String(20))
    filename:Mapped[str]=mapped_column(String(255))
    path:Mapped[str]=mapped_column(String(500))
    mime:Mapped[str]=mapped_column(String(120),default="application/octet-stream")
    size:Mapped[int]=mapped_column(Integer,default=0)
    duration:Mapped[float]=mapped_column(Float,default=0)
    metadata_json:Mapped[dict]=mapped_column(JSON,default=dict)
    project=relationship("Project",back_populates="media")
class Job(Base):
    __tablename__="jobs"
    id:Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    project_id:Mapped[str]=mapped_column(ForeignKey("projects.id"),index=True)
    type:Mapped[str]=mapped_column(String(30))
    status:Mapped[str]=mapped_column(String(30),default="QUEUED")
    progress:Mapped[int]=mapped_column(Integer,default=0)
    message:Mapped[str]=mapped_column(String(255),default="Queued")
    error:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc),onupdate=lambda:datetime.now(timezone.utc))
