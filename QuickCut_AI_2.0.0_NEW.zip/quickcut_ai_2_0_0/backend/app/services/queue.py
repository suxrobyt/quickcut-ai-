import asyncio,traceback
from sqlalchemy.orm import Session
from ..db import SessionLocal
from ..models.entities import Job,Project
from .ai import ai_plan
from .render import render
from pathlib import Path
from ..core.config import settings

async def run_job(job_id):
    db=SessionLocal(); job=db.get(Job,job_id)
    if not job: db.close(); return
    try:
        project=db.get(Project,job.project_id); media=list(project.media)
        if job.type=="AI_EDIT":
            job.status="ANALYZING"; job.message="Analyzing media and understanding your instruction..."; job.progress=20; db.commit(); await asyncio.sleep(.05)
            manifest=[]
            for m in media:
                x={"id":m.id,"kind":m.kind,"filename":m.filename,"path":m.path,"duration":m.duration,**(m.metadata_json or {})}
                manifest.append(x)
            plan=ai_plan(manifest,project.instruction,project.style,project.duration,project.aspect_ratio)
            project.timeline=plan; project.status="PREVIEWING"; job.status="PREVIEWING"; job.progress=60; job.message="Generating preview..."; db.commit()
            out=Path(settings.storage_dir)/project.user_id/project.id/"preview.mp4"; out.parent.mkdir(parents=True,exist_ok=True)
            render(out.parent,plan,str(out),project.aspect_ratio,"720p",next((m.path for m in media if m.kind=="music"),None))
            project.preview_path=str(out); project.status="READY"; job.status="READY"; job.progress=100; job.message="Preview Ready"; db.commit()
        elif job.type=="RENDER":
            job.status="RENDERING"; job.progress=10; job.message="Rendering final video..."; db.commit()
            out=Path(settings.storage_dir)/project.user_id/project.id/"final.mp4"; out.parent.mkdir(parents=True,exist_ok=True)
            render(out.parent,project.timeline,str(out),project.aspect_ratio,"1080p",next((m.path for m in project.media if m.kind=="music"),None))
            project.final_path=str(out); project.status="COMPLETED"; job.status="COMPLETED"; job.progress=100; job.message="Ready!"; db.commit()
    except Exception as e:
        job.status="FAILED"; job.error=str(e); job.message="Processing failed. Your project is safe. Try again."; job.progress=0; db.commit(); traceback.print_exc()
    finally: db.close()

def enqueue(job_id):
    asyncio.create_task(run_job(job_id))
