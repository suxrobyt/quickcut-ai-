import json,base64,os,re,httpx,random
from pathlib import Path
from .media import thumbnail,probe
from ..core.config import settings

def fallback_plan(media,instruction,style,duration):
    # Deterministic fallback is explicitly non-AI; production uses the configured model.
    items=[]; videos=[m for m in media if m["kind"]=="video"]; photos=[m for m in media if m["kind"]=="photo"]
    target={"15":15,"30":30,"60":60,"90":90}.get(duration,30)
    cursor=0.0; pool=videos+photos
    if not pool: return {"duration":target,"clips":[],"reason":"No media"}
    for i,m in enumerate(pool):
        dur=min(3.0,max(1.2,target/len(pool))) if m["kind"]=="video" else min(2.5,max(1.2,target/len(pool)))
        if cursor+dur>target: dur=max(0,target-cursor)
        if dur<=0: break
        items.append({"media_id":m["id"],"kind":m["kind"],"source_start":0,"source_end":dur,"timeline_start":cursor,"timeline_end":cursor+dur,"effect":"zoom_in" if m["kind"]=="photo" else ("cut" if i%3==0 else "zoom"),"transition":"cut" if i==0 else ("flash" if "beat" in instruction.lower() else "fade")})
        cursor+=dur
    return {"duration":round(cursor,2),"clips":items,"caption":None,"notes":"DEMO/FALLBACK plan; configure OPENAI_API_KEY for AI planning."}

def _frame_data(path, second=1.0):
    try:
        import tempfile
        out=Path(tempfile.gettempdir())/f"qc_{random.randint(1,10**9)}.jpg"
        thumbnail(path,str(out),second)
        raw=out.read_bytes()
        out.unlink(missing_ok=True)
        return "data:image/jpeg;base64,"+base64.b64encode(raw).decode()
    except Exception:
        return None

def build_prompt(media,instruction,style,duration,aspect):
    manifest=[{k:m.get(k) for k in ("id","kind","filename","duration","width","height","audio","analysis")} for m in media]
    return f"""You are the editing planner for QuickCut AI. Understand the user's instruction in Uzbek or any language. Never invent media moments. Return only JSON matching the schema. Use media IDs exactly from the manifest. Select useful portions; avoid repetition. Respect requested style, aspect ratio, and duration. If the user references a moment that cannot be verified from the supplied frames/metadata, choose a high-action segment only when supported and state uncertainty in notes. User instruction: {instruction}\nStyle: {style}\nDuration: {duration}\nAspect: {aspect}\nManifest: {json.dumps(manifest,ensure_ascii=False)}"""

def ai_plan(media,instruction,style,duration,aspect):
    if not settings.openai_api_key: return fallback_plan(media,instruction,style,duration)
    schema={"type":"object","properties":{"duration":{"type":"number"},"clips":{"type":"array","items":{"type":"object","properties":{"media_id":{"type":"string"},"kind":{"type":"string"},"source_start":{"type":"number"},"source_end":{"type":"number"},"timeline_start":{"type":"number"},"timeline_end":{"type":"number"},"effect":{"type":"string"},"transition":{"type":"string"},"crop":{"type":"string"}},"required":["media_id","kind","source_start","source_end","timeline_start","timeline_end","effect","transition","crop"],"additionalProperties":False}},"caption":{"type":["string","null"]},"notes":{"type":"string"}},"required":["duration","clips","caption","notes"],"additionalProperties":False}
    content=[{"type":"input_text","text":build_prompt(media,instruction,style,duration,aspect)}]
    # Give the vision-capable model a small, representative sample of frames.
    for m in media:
        if m.get("kind")=="video" and m.get("path") and os.path.exists(m["path"]):
            d=float(m.get("duration") or 0)
            for sec in sorted(set([0.1,min(1.0,max(0.1,d/2)),max(0.1,d-0.2)]))[:3]:
                img=_frame_data(m["path"],sec)
                if img: content.append({"type":"input_image","image_url":img,"detail":"low"})
        if len(content)>=13: break
    payload={"model":settings.openai_model,"input":[{"role":"developer","content":[{"type":"input_text","text":"Create a realistic edit timeline from the supplied media evidence. Do not hallucinate events."}]},{"role":"user","content":content}],"text":{"format":{"type":"json_schema","name":"edit_plan","strict":True,"schema":schema}}}
    r=httpx.post("https://api.openai.com/v1/responses",headers={"Authorization":f"Bearer {settings.openai_api_key}","Content-Type":"application/json"},json=payload,timeout=180)
    r.raise_for_status(); data=r.json(); txt=data.get("output_text")
    if not txt:
        for item in data.get("output",[]):
            for c in item.get("content",[]):
                if c.get("type")=="output_text": txt=c.get("text"); break
            if txt: break
    if not txt: raise RuntimeError("AI returned no edit plan")
    return json.loads(txt)
