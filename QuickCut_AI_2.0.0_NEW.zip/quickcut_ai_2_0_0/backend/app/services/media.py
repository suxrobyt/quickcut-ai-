import json,subprocess,os,shutil
from pathlib import Path
from PIL import Image

def probe(path):
    try:
        p=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration,size:stream=index,codec_name,width,height,r_frame_rate,codec_type","-of","json",path],capture_output=True,text=True,check=True)
        d=json.loads(p.stdout); streams=d.get("streams",[]); fmt=d.get("format",{})
        video=next((s for s in streams if s.get("codec_type")=="video"),None); audio=next((s for s in streams if s.get("codec_type")=="audio"),None)
        return {"duration":float(fmt.get("duration") or 0),"size":int(float(fmt.get("size") or 0)),"width":video.get("width",0) if video else 0,"height":video.get("height",0) if video else 0,"video_codec":video.get("codec_name") if video else None,"audio":bool(audio),"fps":video.get("r_frame_rate") if video else None}
    except Exception as e: return {"duration":0,"size":os.path.getsize(path),"error":str(e)}
def thumbnail(video_path,out_path,second=1):
    subprocess.run(["ffmpeg","-y","-ss",str(second),"-i",video_path,"-frames:v","1","-vf","scale=512:-2",out_path],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return out_path
def image_info(path):
    with Image.open(path) as im: return {"width":im.width,"height":im.height}
