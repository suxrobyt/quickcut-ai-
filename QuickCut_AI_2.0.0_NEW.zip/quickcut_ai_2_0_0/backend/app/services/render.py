import subprocess,os,shlex
from pathlib import Path

def render(project_dir,timeline,out_file,aspect="9:16",quality="1080p",music=None):
    clips=timeline.get("clips",[])
    if not clips: raise RuntimeError("No clips in timeline")
    width,height={"9:16":(1080,1920),"16:9":(1920,1080),"1:1":(1080,1080),"4:5":(1080,1350)}.get(aspect,(1080,1920))
    if quality=="720p":
        scale=0.666; width=int(width*scale)//2*2; height=int(height*scale)//2*2
    elif quality=="4k": width,height=(2160,3840) if aspect=="9:16" else ((3840,2160) if aspect=="16:9" else (2160,2160))
    inputs=[]; filters=[]
    for i,c in enumerate(clips):
        p=str(Path(project_dir)/c["filename"]); inputs += (["-loop","1","-i",p] if c.get("kind")=="photo" else ["-i",p])
        vf=f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height}"
        if c.get("kind")=="photo": vf += ",zoompan=z='min(zoom+0.0015,1.10)':d=75:s=%sx%s"%(width,height)
        if c.get("effect")=="zoom": vf += ",scale=iw*1.08:ih*1.08,crop=iw/1.08:ih/1.08"
        filters.append(f"[{i}:v]trim=start={max(0,float(c.get("source_start",0)))}:end={max(float(c.get("source_start",0))+0.2,float(c.get("source_end",0)))},setpts=PTS-STARTPTS,{vf},fps=30,format=yuv420p[v{i}]")
    concat=''.join(f'[v{i}]' for i in range(len(clips)))+f'concat=n={len(clips)}:v=1:a=0[vout]'
    cmd=["ffmpeg","-y",*inputs,"-filter_complex",";".join(filters+[concat]),"-map","[vout]"]
    if music and os.path.exists(music): cmd += ["-stream_loop","-1","-i",music,"-map",f"{len(clips)}:a","-t",str(timeline.get("duration",30)),"-af","volume=0.8,afade=t=out:st=max(0,%.2f-1):d=1"%timeline.get("duration",30)]
    else: cmd += ["-f","lavfi","-i","anullsrc=r=48000:cl=stereo","-shortest"]
    cmd += ["-c:v","libx264","-preset","veryfast","-crf","20","-c:a","aac","-b:a","192k","-movflags","+faststart",out_file]
    subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    return out_file
