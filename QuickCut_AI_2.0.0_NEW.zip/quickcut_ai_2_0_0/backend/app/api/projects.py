import os,uuid,asyncio,shutil
from pathlib import Path
from fastapi import APIRouter,Depends,HTTPException,UploadFile,File,Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from ..db import get_db
from ..models.entities import Project,Media,Job
from ..models.schemas import ProjectIn,ProjectOut,EditRequest,RenderRequest
from ..security import current_user
from ..core.config import settings
from ..services.media import probe,image_info
from ..services.queue import enqueue
router=APIRouter(prefix="/projects",tags=["projects"])
def out(p):
    base=settings.public_base_url.rstrip('/')
    return ProjectOut(id=p.id,name=p.name,instruction=p.instruction,style=p.style,aspect_ratio=p.aspect_ratio,duration=p.duration,status=p.status,timeline=p.timeline or {},preview_url=f"{base}/files/{p.id}/preview" if p.preview_path else None,final_url=f"{base}/files/{p.id}/final" if p.final_path else None)
def own(db,pid,u):
    p=db.get(Project,pid)
    if not p or p.user_id!=u.id: raise HTTPException(404,"Project not found")
    return p
@router.post("",response_model=ProjectOut)
def create(x:ProjectIn,db:Session=Depends(get_db),u=Depends(current_user)):
    p=Project(user_id=u.id,**x.model_dump()); db.add(p); db.commit(); db.refresh(p); return out(p)
@router.get("",response_model=list[ProjectOut])
def list_projects(db:Session=Depends(get_db),u=Depends(current_user)):
    return [out(p) for p in db.query(Project).filter(Project.user_id==u.id).order_by(Project.updated_at.desc()).all()]
@router.get("/{pid}",response_model=ProjectOut)
def get(pid:str,db:Session=Depends(get_db),u=Depends(current_user)): return out(own(db,pid,u))
@router.patch("/{pid}",response_model=ProjectOut)
def update(pid:str,x:ProjectIn,db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u); [setattr(p,k,v) for k,v in x.model_dump().items()]; db.commit(); db.refresh(p); return out(p)
@router.delete("/{pid}")
def delete(pid:str,db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u); root=Path(settings.storage_dir)/u.id/p.id; db.delete(p); db.commit(); shutil.rmtree(root,ignore_errors=True); return {"ok":True}
@router.post("/{pid}/media/chunk")
async def chunk(pid:str,file:UploadFile=File(...),chunk_index:int=Form(...),total_chunks:int=Form(...),upload_id:str=Form(...),kind:str=Form(...),filename:str=Form(...),db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u); d=Path(settings.storage_dir)/u.id/p.id/"chunks"/upload_id; d.mkdir(parents=True,exist_ok=True); target=d/f"{chunk_index:08d}.part"; target.write_bytes(await file.read())
    if chunk_index==total_chunks-1:
        finaldir=Path(settings.storage_dir)/u.id/p.id; finaldir.mkdir(parents=True,exist_ok=True); safe=Path(filename).name; final=finaldir/f"{uuid.uuid4().hex}_{safe}"
        with final.open('wb') as out:
            for i in range(total_chunks):
                part=d/f"{i:08d}.part"
                if not part.exists(): raise HTTPException(400,"Missing upload chunk")
                with part.open('rb') as f: shutil.copyfileobj(f,out)
        meta=probe(str(final)) if kind in ('video','music') else image_info(str(final))
        m=Media(project_id=p.id,kind=kind,filename=final.name,path=str(final),mime=file.content_type or 'application/octet-stream',size=final.stat().st_size,duration=float(meta.get('duration',0)),metadata_json=meta); db.add(m); db.commit(); shutil.rmtree(d,ignore_errors=True)
        return {"complete":True,"media_id":m.id,"metadata":meta}
    return {"complete":False,"chunk_index":chunk_index}
@router.delete("/{pid}/media/{mid}")
def delete_media(pid,mid,db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u); m=db.get(Media,mid)
    if not m or m.project_id!=p.id: raise HTTPException(404,"Media not found")
    try: os.remove(m.path)
    except OSError: pass
    db.delete(m); db.commit(); return {"ok":True}
@router.post("/{pid}/ai/create-edit")
def ai_edit(pid:str,x:EditRequest,db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u); p.instruction=x.instruction; p.status="QUEUED"; db.commit(); j=Job(project_id=p.id,type="AI_EDIT"); db.add(j); db.commit(); db.refresh(j); enqueue(j.id); return {"job_id":j.id,"status":j.status}
@router.post("/{pid}/regenerate")
def regen(pid:str,db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u); p.status="QUEUED"; db.commit(); j=Job(project_id=p.id,type="AI_EDIT"); db.add(j); db.commit(); db.refresh(j); enqueue(j.id); return {"job_id":j.id}
@router.post("/{pid}/render")
def render_final(pid:str,x:RenderRequest,db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u)
    if not p.timeline: raise HTTPException(400,"Create an AI edit first")
    j=Job(project_id=p.id,type="RENDER"); db.add(j); p.status="RENDERING"; db.commit(); db.refresh(j); enqueue(j.id); return {"job_id":j.id}
@router.get("/{pid}/media")
def media(pid,db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u); return [{"id":m.id,"kind":m.kind,"filename":m.filename,"duration":m.duration,"size":m.size,"metadata":m.metadata_json} for m in p.media]
@router.get("/{pid}/jobs/{jid}")
def job(pid,jid,db:Session=Depends(get_db),u=Depends(current_user)):
    p=own(db,pid,u); j=db.get(Job,jid)
    if not j or j.project_id!=p.id: raise HTTPException(404,"Job not found")
    return {"id":j.id,"status":j.status,"progress":j.progress,"message":j.message,"error":j.error}
