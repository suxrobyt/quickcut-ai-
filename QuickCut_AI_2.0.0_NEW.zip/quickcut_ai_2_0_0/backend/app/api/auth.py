from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..models.entities import User
from ..models.schemas import RegisterIn,LoginIn
from ..security import hash_password,verify_password,token_for
router=APIRouter(prefix="/auth",tags=["auth"])
@router.post("/register")
def register(x:RegisterIn,db:Session=Depends(get_db)):
    if db.query(User).filter(User.email==x.email.lower()).first(): raise HTTPException(409,"Email already registered")
    u=User(email=x.email.lower(),password_hash=hash_password(x.password)); db.add(u); db.commit(); db.refresh(u)
    return {"access_token":token_for(u),"user":{"id":u.id,"email":u.email}}
@router.post("/login")
def login(x:LoginIn,db:Session=Depends(get_db)):
    u=db.query(User).filter(User.email==x.email.lower()).first()
    if not u or not verify_password(x.password,u.password_hash): raise HTTPException(401,"Invalid email or password")
    return {"access_token":token_for(u),"user":{"id":u.id,"email":u.email}}
