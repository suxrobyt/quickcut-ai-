from datetime import datetime,timedelta,timezone
import jwt
from passlib.context import CryptContext
from fastapi import Depends,HTTPException,status
from fastapi.security import HTTPBearer,HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from .core.config import settings
from .db import get_db
from .models.entities import User
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto")
bearer=HTTPBearer(auto_error=False)
def hash_password(p): return pwd.hash(p)
def verify_password(p,h): return pwd.verify(p,h)
def token_for(user): return jwt.encode({"sub":user.id,"exp":datetime.now(timezone.utc)+timedelta(days=7)},settings.secret_key,algorithm="HS256")
def current_user(creds:HTTPAuthorizationCredentials=Depends(bearer),db:Session=Depends(get_db)):
    if not creds: raise HTTPException(status_code=401,detail="Authentication required")
    try: payload=jwt.decode(creds.credentials,settings.secret_key,algorithms=["HS256"]); uid=payload["sub"]
    except Exception: raise HTTPException(status_code=401,detail="Invalid token")
    user=db.get(User,uid)
    if not user: raise HTTPException(status_code=401,detail="User not found")
    return user
