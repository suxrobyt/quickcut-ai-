from fastapi import FastAPI,Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pathlib import Path
from .db import Base,engine
from .api.auth import router as auth_router
from .api.projects import router as project_router
from .core.config import settings
from .security import current_user
Base.metadata.create_all(bind=engine)
app=FastAPI(title="QuickCut AI",version="2.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(auth_router,prefix="/api")
app.include_router(project_router,prefix="/api")
@app.get("/health")
def health(): return {"ok":True,"version":"2.0.0"}
@app.get("/files/{pid}/{kind}")
def serve(pid:str,kind:str,u=Depends(current_user)):
    matches=list((Path(settings.storage_dir)/u.id/pid).glob(f"{kind}.mp4"))
    if not matches: return {"error":"not found"}
    return FileResponse(matches[0],media_type="video/mp4")
