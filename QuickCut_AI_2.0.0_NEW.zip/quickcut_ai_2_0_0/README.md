# QuickCut AI 2.0.0 — Complete MVP

## What is included
- Flutter mobile-first UI for Android/Web.
- Email/password authentication with JWT.
- Multi-video, multi-photo and music selection.
- 8 MB resumable chunk upload with retry-friendly API semantics.
- FFprobe media validation and metadata.
- Uzbek natural-language editing instruction field.
- Real server-side AI planning through OpenAI Responses API when `OPENAI_API_KEY` is configured; structured JSON edit plans are enforced.
- Explicit DEMO/FALLBACK plan when AI credentials are not configured.
- Asynchronous AI and rendering jobs.
- FFmpeg preview/final rendering.
- 9:16/16:9/1:1/4:5, 720p/1080p/4K render code paths.
- Project persistence, media metadata, job status, regenerate, export.
- Server-side secrets only.

## Run backend
Install FFmpeg, then:
```bash
cd backend
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# put OPENAI_API_KEY in .env for real AI planning
uvicorn app.main:app --reload --port 8000
```

## Run Flutter
```bash
cd frontend
flutter pub get
flutter run
```
Android emulator uses `10.0.2.2`. For a physical Android phone, point `base` at your computer's LAN IP.

## Production notes
Object storage, CDN, Redis/Celery, PostgreSQL, signed URLs, OAuth providers, push notifications and GPU workers should be enabled with the provider credentials for deployment. The API and service boundaries are already separated so these can replace the local adapters without rewriting the Flutter flow.

## AI behavior
The planner receives the user's instruction plus a verified media manifest. It returns a structured timeline. It must not invent a clip or event that is absent from the manifest. For stronger visual moment detection, add sampled frame images to the AI input; the service interface is intentionally isolated for that provider integration.
