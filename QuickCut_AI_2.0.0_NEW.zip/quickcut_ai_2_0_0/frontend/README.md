# QuickCut AI Flutter

Run `flutter pub get` then `flutter run`. Android emulator backend defaults to `http://10.0.2.2:8000`. For a physical phone, change `base` in `main.dart` to the LAN IP of the backend.
