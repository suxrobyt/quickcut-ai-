import 'dart:typed_data';
import 'package:dio/dio.dart';
class Api {
  final Dio dio;
  Api(String base, {String? token}): dio=Dio(BaseOptions(baseUrl:base,connectTimeout:const Duration(seconds:20),receiveTimeout:const Duration(seconds:60),headers:token==null?{}:{'Authorization':'Bearer $token'}));
  Future<Map<String,dynamic>> register(String email,String password)=>dio.post('/api/auth/register',data:{'email':email,'password':password}).then((r)=>Map<String,dynamic>.from(r.data));
  Future<Map<String,dynamic>> login(String email,String password)=>dio.post('/api/auth/login',data:{'email':email,'password':password}).then((r)=>Map<String,dynamic>.from(r.data));
  Future<List<dynamic>> projects()=>dio.get('/api/projects').then((r)=>r.data as List);
  Future<Map<String,dynamic>> createProject(Map<String,dynamic> data)=>dio.post('/api/projects',data:data).then((r)=>Map<String,dynamic>.from(r.data));
  Future<Map<String,dynamic>> createEdit(String id,String instruction)=>dio.post('/api/projects/$id/ai/create-edit',data:{'instruction':instruction}).then((r)=>Map<String,dynamic>.from(r.data));
  Future<Map<String,dynamic>> regenerate(String id)=>dio.post('/api/projects/$id/regenerate').then((r)=>Map<String,dynamic>.from(r.data));
  Future<Map<String,dynamic>> render(String id)=>dio.post('/api/projects/$id/render',data:{'quality':'1080p'}).then((r)=>Map<String,dynamic>.from(r.data));
  Future<Map<String,dynamic>> job(String pid,String jid)=>dio.get('/api/projects/$pid/jobs/$jid').then((r)=>Map<String,dynamic>.from(r.data));
  Future<void> uploadChunk(String pid, String path, String kind, int index, int total, String uploadId, Uint8List bytes, void Function(int,int) progress) async {
    final f=MultipartFile.fromBytes(bytes,filename:path.split('/').last);
    await dio.post('/api/projects/$pid/media/chunk',data:FormData.fromMap({'file':f,'chunk_index':index,'total_chunks':total,'upload_id':uploadId,'kind':kind,'filename':path.split('/').last}),onSendProgress:progress);
  }
}
