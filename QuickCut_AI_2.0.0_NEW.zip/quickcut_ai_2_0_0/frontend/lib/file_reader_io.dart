import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'dart:typed_data';
Future<Uint8List> readChunk(PlatformFile f,int start,int end) async {
  if(f.path==null) throw Exception('Selected file has no local path');
  final file=File(f.path!); final raf=await file.open();
  await raf.setPosition(start); final data=await raf.read(end-start); await raf.close(); return Uint8List.fromList(data);
}
