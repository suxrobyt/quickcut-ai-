import 'package:file_picker/file_picker.dart';
import 'dart:typed_data';
Future<Uint8List> readChunk(PlatformFile f,int start,int end) async {
  final b=f.bytes; if(b==null) throw Exception('Browser did not provide file bytes'); return b.sublist(start,end);
}
